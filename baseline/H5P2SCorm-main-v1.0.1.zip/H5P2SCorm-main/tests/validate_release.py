from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]

version = (ROOT / 'VERSION').read_text(encoding='utf-8').strip()
app = (ROOT / 'app.js').read_text(encoding='utf-8')
html = (ROOT / 'index.html').read_text(encoding='utf-8')
readme = (ROOT / 'README.md').read_text(encoding='utf-8')
profile = json.loads((ROOT / 'RUNTIME_PROFILE.json').read_text(encoding='utf-8'))

assert version == '1.0.1', f'VERSION inattendue: {version}'
assert f"const APP_VERSION = '{version}'" in app, 'APP_VERSION incohérente avec VERSION'
assert f'Version {version}' in html, 'Version visible de l interface incohérente'
assert readme.startswith(f'# H5P vers SCORM 1.2 - version {version}'), 'README version incohérente'
assert profile['applicationVersion'] == version, 'RUNTIME_PROFILE version incohérente'

player_match = re.search(r"const PLAYER_VERSION = '([^']+)'", app)
assert player_match, 'PLAYER_VERSION introuvable'
player_version = player_match.group(1)
assert profile['player']['version'] == player_version, 'Version lecteur incohérente'
assert f'h5p-standalone@${{PLAYER_VERSION}}' in app, 'URL lecteur non liée à PLAYER_VERSION'

core_match = re.search(r'H5P_CORE_API_SUPPORTED = Object\.freeze\(\{ majorVersion: (\d+), minorVersion: (\d+) \}\)', app)
assert core_match, 'Plafond Core API introuvable'
core = {'majorVersion': int(core_match.group(1)), 'minorVersion': int(core_match.group(2))}
assert profile['h5pCoreApi']['declaredCompatibilityCeiling'] == core, 'Plafond Core API incohérent'

for required in [
    'MAINTENANCE_MANIFEST.md', 'RUNTIME_PROFILE.json', 'COMPATIBILITY.md', 'MOODLE.md',
    'CHANGELOG.md', 'THIRD_PARTY_NOTICES.md'
]:
    assert (ROOT / required).is_file(), f'Fichier de release manquant: {required}'

assert '@latest' not in app, 'app.js ne doit pas dépendre de @latest'
assert '@latest' not in html, 'index.html ne doit pas dépendre de @latest'

print(f'Release {version} cohérente : OK')
